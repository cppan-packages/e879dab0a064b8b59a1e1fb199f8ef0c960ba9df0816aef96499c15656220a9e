#include "ace/Active_Map_Manager.h"

#if !defined (__ACE_INLINE__)
#include "ace/Active_Map_Manager.inl"
#endif /* __ACE_INLINE__ */
