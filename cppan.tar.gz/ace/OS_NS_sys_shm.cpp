#include "ace/OS_NS_sys_shm.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_shm.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

