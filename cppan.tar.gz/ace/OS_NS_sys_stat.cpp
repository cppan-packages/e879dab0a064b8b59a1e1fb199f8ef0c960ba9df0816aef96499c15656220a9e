#include "ace/OS_NS_sys_stat.h"

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_stat.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

